<?php
/**
 * @copyright Copyright (c) 2012, {@link http://aksw.org AKSW}
 * @license http://opensource.org/licenses/gpl-license.php GNU General Public License(GPL)
 */

/**
 * gets the main page
 */
class IndexController extends Zend_Controller_Action
{
    /**
     * This function changes the title of the header and calls up the view.
     * @param string $titel - Additive for the title in the header of the Main.phtml
     * @author Peter Kornowski
     */
    public function indexAction()
    {
        $this->view->title = ' - Hauptseite';
//My_Plugin_Impo::sayHello();
    }

    public function preloginAction()
    {
        $this->view->title = ' - Admin';
    }

    public function loginAction()
    {
        if ($this->getRequest()->isPost())
        {
            $usern = $this->_request->getPost('usern');
            $password = $this->_request->getPost('password');
               
            if (empty($usern) || empty($password))
            {
                $this->_redirect('/');
            }
            else
            {      
                $db = Zend_Db_Table::getDefaultAdapter();
                $authAdapter = new Zend_Auth_Adapter_DbTable($db);
                
                $authAdapter->setTableName('account');
                $authAdapter->setIdentityColumn('usern');
                $authAdapter->setCredentialColumn('pswd');
                $authAdapter->setCredentialTreatment('MD5(?)');
                
                $authAdapter->setIdentity($usern);
                $authAdapter->setCredential($password);
                
                $auth = Zend_Auth::getInstance();
                $result = $auth->authenticate($authAdapter);
                // Did the participant successfully login?
                if ($result->isValid())
                {      
                    $this->_redirect('/'); 
                }
                else
                {
                    $this->view->error = "Login failed. Have you confirmed your account?";
                }
            }
        }
        else  
        {
            $this->_redirect('/');
        }  
    }

    public function logoutAction()
    {
        Zend_Auth::getInstance()->clearIdentity();
        $this->_redirect('/');
    }

    public function preupdateAction()
    {
        if (Zend_Auth::getInstance()->getIdentity())
        {
            $this->view->title = ' - Admin';
        }
        else  
        {
            $this->_redirect('/');
        }
    }

    public function leupdateAction()
    {
        if ($this->getRequest()->isPost())
        {
            $usern = $this->_request->getPost('usern');
            $password = $this->_request->getPost('password');
            
            if (!empty($usern))
            {
                $accounts = new AccountModel;

                $data = array('usern' => $usern);

                $n = $accounts->update($data, 'accountID = 1');
            }
            if(!empty($password))
            {      
                $accounts = new AccountModel;

                $data = array('pswd' => md5($password));

                $n = $accounts->update($data, 'accountID = 1');
            }
            $this->_redirect('/');
        }
        else  
        {
            $this->_redirect('/');
        }
    }
}
?>
