-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 10. Apr 2012 um 09:43
-- Server Version: 5.5.16
-- PHP-Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `comments`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `accountID` int(11) NOT NULL AUTO_INCREMENT,
  `usern` varchar(50) NOT NULL,
  `pswd` char(32) NOT NULL,
  PRIMARY KEY (`accountID`),
  UNIQUE KEY `usern` (`usern`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Daten für Tabelle `account`
--

INSERT INTO `account` (`accountID`, `usern`, `pswd`) VALUES
(1, 'admin', '098f6bcd4621d373cade4e832627b4f6');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `commentID` int(11) NOT NULL AUTO_INCREMENT,
  `topicID` int(11) NOT NULL,
  `userName` varchar(20) DEFAULT NULL,
  `commentDate` datetime NOT NULL,
  `commentText` varchar(500) NOT NULL,
  PRIMARY KEY (`commentID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Daten für Tabelle `comment`
--

INSERT INTO `comment` (`commentID`, `topicID`, `userName`, `commentDate`, `commentText`) VALUES
(1, 1, 'Mr. Pencil', '2012-03-18 01:12:20', 'I wouldn''t like it to see such a picture every time I smoke.'),
(2, 1, 'Hans', '2012-03-18 10:54:07', 'When did you make this picture?'),
(3, 3, 'Anonymus', '2012-03-19 18:14:47', ':('),
(4, 3, 'Fotograph', '2012-03-19 19:20:20', 'Das war in GroÃŸbritannien. In Deutschland findet man sowas nicht. ;)'),
(6, 1, 'Admin', '2012-03-19 19:23:51', 'It was 2009 so not that old.\r\nI don''t know when they start to print such pictures.'),
(7, 2, 'InsektenfÃ¼hrer', '2012-03-21 10:50:48', 'Die Kirche ist gar nicht geschlossen. Da ist jetzt einfach nur eine Sekte drin. ^^'),
(8, 1, 'Horst', '2012-03-21 13:32:08', 'coooool'),
(9, 1, 'Anonymus', '2012-03-21 13:32:42', 'this is sad'),
(13, 2, 'Horst', '2012-03-22 15:09:00', 'Is the church so poor?'),
(16, 2, 'Programmierer', '2012-03-29 15:45:34', 'Das soll ein richtig langer Kommentar sein, der Ã¼ber mehrere Zeilen geht, da ich testen will, wie sich das auf das Layout der Seite auswirkt. Ich nehme an, dass es keine Probleme geben wird, aber man kann ja nie wissen. Vielleicht schleicht sich doch die eine oder andere Ungereimtheit ein.\r\nIch denke, dass es jetzt lang genug ist.\r\nMal schauen...'),
(17, 3, 'green', '2012-03-29 16:06:31', 'D'':'),
(18, 3, 'JÃ¶rgen', '2012-04-01 15:31:21', 'Ich bin der JÃ¶rgen'),
(19, 1, 'Trueman', '2012-04-05 15:23:42', 'true');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `topic`
--

CREATE TABLE IF NOT EXISTS `topic` (
  `topicID` int(11) NOT NULL AUTO_INCREMENT,
  `topicName` varchar(30) NOT NULL,
  `topicContent` varchar(100) NOT NULL,
  PRIMARY KEY (`topicID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Daten für Tabelle `topic`
--

INSERT INTO `topic` (`topicID`, `topicName`, `topicContent`) VALUES
(1, 'Smokers Die Younger', 'http://localhost/BComment/public/_files/images/IMG_2972.jpg'),
(2, 'Deserted Church', 'http://localhost/BComment/public/_files/images/IMG_2776.jpg'),
(3, 'Litter', 'http://localhost/BComment/public/_files/images/IMG_2821.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
