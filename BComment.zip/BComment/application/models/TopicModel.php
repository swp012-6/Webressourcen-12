<?php
class TopicModel extends Zend_Db_Table_Abstract
{
    protected $_name = 'topic';
}
?>
