<?php
class CommentModel extends Zend_Db_Table_Abstract
{
    protected $_name = 'comment';
}
?>
